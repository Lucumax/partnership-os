# 06. Acceptance criteria

## Release verdict target

**SHIP FOR PORTFOLIO DEMO**

The MVP may ship when all critical criteria pass.

## 1. Functional criteria

- [ ] App loads without any external API key.
- [ ] Synthetic Atlas case is available from the dashboard.
- [ ] Proposal intake displays all major terms.
- [ ] Downside, base, and upside scenarios calculate correctly.
- [ ] Confidence-adjusted value is shown separately from gross value.
- [ ] Selected comparables and normalization notes are visible.
- [ ] Negotiation brief includes opening, target, reservation, and walk-away values.
- [ ] Human approval is required before final decision status.
- [ ] Audit trail records assumption and recommendation changes.
- [ ] Markdown export works.
- [ ] Print-friendly case summary renders cleanly.

## 2. Evidence and integrity criteria

- [ ] Every demo fact is labeled synthetic.
- [ ] No Anthropic confidential or implied internal information appears.
- [ ] Every comparable has a source type and confidence score.
- [ ] AI-generated content is labeled.
- [ ] Human approval status is visible.
- [ ] Assumptions driving the recommendation are inspectable.
- [ ] Recommendation changes when core assumptions change.
- [ ] No hidden hard-coded final recommendation bypasses the model.

## 3. Technical criteria

- [ ] TypeScript strict mode passes.
- [ ] Lint passes with zero errors.
- [ ] Unit tests cover core formulas.
- [ ] Tests cover confidence factor boundaries.
- [ ] Tests cover scenario recomputation.
- [ ] Tests cover export generation.
- [ ] Playwright smoke test completes the demo flow.
- [ ] Build succeeds.
- [ ] No secret values are present in client bundles.
- [ ] Live-AI feature flags default to false.

## 4. UX criteria

- [ ] Viewer understands the case in under 60 seconds.
- [ ] Viewer can find the recommendation in one click.
- [ ] No screen resembles a generic chatbot.
- [ ] Tables remain readable at laptop width.
- [ ] Important assumptions and risks do not require scrolling through raw JSON.
- [ ] The interface is usable in a 5-minute interview walkthrough.

## 5. Demo script

### Minute 0–1: Decision problem

Open Atlas case and explain the proposal, economic commitment, and missing evidence.

### Minute 1–2: Valuation

Show the three scenarios, base-case waterfall, confidence factor, and top sensitivities.

### Minute 2–3: Comparables

Show how imperfect comparables are normalized rather than treated as exact matches.

### Minute 3–4: Negotiation

Show the target range, walk-away point, and staged-pilot recommendation.

### Minute 4–5: AI and governance

Show AI draft labeling, human approvals, assumption history, and how the recommendation changes when adoption or exclusivity assumptions change.

## 6. Portfolio screenshots

Capture only:

1. Atlas opportunity overview.
2. Valuation workbench.
3. Negotiation brief.
4. Audit/traceability view.

Screenshots must be tightly cropped, high resolution, and free of browser clutter.

# 08. Build prompt for V4 Flash

You are building a portfolio-quality MVP called **Partnership Value OS**.

Read, in order:

1. README.md
2. 01_PRODUCT_SPEC.md
3. 02_DATA_MODEL.md
4. 03_WORKFLOWS_AND_AI.md
5. 04_UI_WIREFRAME.md
6. 05_SYNTHETIC_DEMO_DATA.md
7. 06_ACCEPTANCE_CRITERIA.md

## Objective

Build a polished, local-first Next.js application that demonstrates how a senior Strategy & Operations professional would value, negotiate, and operationalize a novel data/product partnership when comparables are sparse.

The artifact must be useful in a five-minute interview walkthrough and credible as an internal strategy/finance tool.

## Required stack

- Next.js 16 App Router
- TypeScript strict mode
- Tailwind CSS
- shadcn/ui or equivalent accessible components
- Recharts
- Zod
- Vitest
- Playwright

Do not add a database in v1 unless the repository already has a clean adapter pattern. Use local fixtures and repository interfaces so persistence can be added later.

## Non-negotiable constraints

- All demo data is synthetic.
- No real Anthropic deal data.
- No API key required for the default experience.
- Live AI is disabled by default.
- The app must not look like a generic chatbot.
- No autonomous approval or external communication.
- Every important recommendation must expose assumptions, evidence, confidence, and human approval status.

## Required routes

- `/` portfolio dashboard
- `/opportunities/atlas` opportunity overview
- `/opportunities/atlas/proposal`
- `/opportunities/atlas/valuation`
- `/comparables`
- `/opportunities/atlas/negotiation`
- `/opportunities/atlas/audit`

## Required implementation order

1. Inspect existing repository and report current state.
2. Create typed schemas and fixture data.
3. Implement deterministic valuation engine with unit tests.
4. Implement dashboard and Atlas case screens.
5. Implement comparable library and normalization display.
6. Implement negotiation brief.
7. Implement audit trail and approval states.
8. Implement Markdown/JSON/CSV exports.
9. Add Playwright demo-flow smoke test.
10. Run all acceptance gates.

## Required calculations

Implement the formulas in `02_DATA_MODEL.md` and ensure the seeded case produces the scenario values in `05_SYNTHETIC_DEMO_DATA.md` within rounding tolerance.

## Visual requirements

- Internal executive-tool aesthetic.
- Restrained palette.
- Clear tables and charts.
- Assumptions and sources always accessible.
- No oversized hero section.
- No stock imagery.
- No conversational assistant panel as the primary UI.

## AI architecture

Create an interface for AI-assisted actions, but ship a deterministic fixture implementation.

Example:

```ts
interface PartnershipAnalysisAssistant {
  extractTerms(input: string): Promise<ProposalTerms>;
  generateDiligenceQuestions(context: Opportunity): Promise<string[]>;
  challengeAssumptions(context: Opportunity): Promise<ChallengeFinding[]>;
  draftNegotiationBrief(context: Opportunity): Promise<Recommendation>;
}
```

Provide:

- `FixturePartnershipAnalysisAssistant`
- optional `ClaudePartnershipAnalysisAssistant` stub behind feature flags

Do not implement live Claude calls unless explicitly authorized and credentials are present.

## Acceptance gates

Run and report:

- lint
- typecheck
- unit tests
- Playwright smoke test
- production build
- secret scan
- fixture validation
- visual review at desktop width

## Final deliverable

Return:

1. architecture summary;
2. files created/changed;
3. test results;
4. screenshots generated;
5. exact demo route;
6. known limitations;
7. SHIP/HOLD verdict.

Do not deploy, commit, or contact external services without explicit authorization.

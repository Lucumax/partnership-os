# 02. Data model

## 1. Core entities

### Opportunity

```ts
interface Opportunity {
  id: string;
  name: string;
  partnerAlias: string;
  archetype: 'data_licensing' | 'product_integration' | 'distribution' | 'strategic_ecosystem' | 'hybrid';
  stage: 'inbound' | 'diligence' | 'valuation' | 'negotiation' | 'approval' | 'contracting' | 'active' | 'declined';
  owner: string;
  createdAt: string;
  decisionDate?: string;
  renewalDate?: string;
  proposal: ProposalTerms;
  assumptions: Assumption[];
  selectedComparableIds: string[];
  scenarios: Scenario[];
  risks: RiskItem[];
  recommendation?: Recommendation;
  approvals: Approval[];
  auditEvents: AuditEvent[];
}
```

### Proposal terms

```ts
interface ProposalTerms {
  termMonths: number;
  cashConsiderationUsd: number;
  minimumCommitmentUsd?: number;
  usageCommitment?: number;
  exclusivity: 'none' | 'limited' | 'category' | 'full';
  territory?: string[];
  dataRights?: string[];
  productRights?: string[];
  distributionCommitments?: string[];
  implementationObligations?: string[];
  renewalMechanics?: string;
  terminationRights?: string;
  nonCashValueNotes?: string;
  sourceLabel: string;
  sourceType: 'synthetic' | 'public' | 'internal';
}
```

### Assumption

```ts
interface Assumption {
  id: string;
  category: 'usage' | 'revenue' | 'cost' | 'timing' | 'risk' | 'renewal' | 'strategic' | 'other';
  label: string;
  value: number | string | boolean;
  unit?: string;
  scenarioValues?: {
    downside: number | string | boolean;
    base: number | string | boolean;
    upside: number | string | boolean;
  };
  evidenceId?: string;
  confidence: 'low' | 'medium' | 'high';
  owner: string;
  lastUpdatedAt: string;
}
```

### Comparable

```ts
interface ComparableTransaction {
  id: string;
  name: string;
  archetype: Opportunity['archetype'];
  announcementDate: string;
  disclosedValueUsd?: number;
  termMonths?: number;
  cashComponentUsd?: number;
  inKindValueUsd?: number;
  exclusivity: ProposalTerms['exclusivity'];
  minimumUsage?: number;
  distributionCommitment?: string;
  integrationBurden: 1 | 2 | 3 | 4 | 5;
  strategicRights?: string[];
  sourceUrl?: string;
  sourceLabel: string;
  sourceQuality: 1 | 2 | 3 | 4 | 5;
  comparabilityScore: number;
  normalizationFactors: NormalizationFactor[];
  notes: string;
  synthetic: boolean;
}
```

### Scenario

```ts
interface Scenario {
  id: string;
  name: 'downside' | 'base' | 'upside';
  directFinancialValueUsd: number;
  usageCustomerValueUsd: number;
  productCapabilityValueUsd: number;
  distributionValueUsd: number;
  strategicOptionValueUsd: number;
  learningValueUsd: number;
  implementationCostUsd: number;
  exclusivityOpportunityCostUsd: number;
  expectedRiskCostUsd: number;
  concentrationLockInCostUsd: number;
  confidenceFactor: number;
  grossPartnershipValueUsd: number;
  confidenceAdjustedValueUsd: number;
  roi: number;
  paybackMonths?: number;
}
```

### Risk item

```ts
interface RiskItem {
  id: string;
  category: 'commercial' | 'legal' | 'privacy' | 'safety' | 'reputational' | 'technical' | 'operational' | 'concentration';
  description: string;
  probability: number;
  impactUsd?: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  mitigation?: string;
  owner?: string;
  status: 'open' | 'mitigated' | 'accepted';
}
```

### Recommendation

```ts
interface Recommendation {
  decision: 'pursue' | 'pilot' | 'restructure' | 'decline' | 'defer';
  openingPositionUsd: number;
  targetValueUsd: number;
  reservationValueUsd: number;
  walkAwayValueUsd: number;
  preferredStructure: string;
  rationale: string[];
  giveGetOptions: GiveGetOption[];
  missingEvidence: string[];
  changeConditions: string[];
  generatedBy: 'human' | 'ai_draft';
  approvedBy?: string;
  approvedAt?: string;
}
```

### Evidence

```ts
interface Evidence {
  id: string;
  title: string;
  sourceType: 'synthetic' | 'public' | 'internal';
  sourceUrl?: string;
  sourceDate?: string;
  excerpt?: string;
  confidence: 'low' | 'medium' | 'high';
  notes?: string;
}
```

### Audit event

```ts
interface AuditEvent {
  id: string;
  timestamp: string;
  actor: string;
  actorType: 'human' | 'system' | 'ai';
  action: string;
  field?: string;
  previousValue?: unknown;
  newValue?: unknown;
  rationale?: string;
  evidenceIds?: string[];
}
```

## 2. Core formulas

### Gross partnership value

```text
GPV = DFV + UCV + PCV + DV + SOV + LV - IC - EOC - ERC - CLC
```

Where:

- DFV = direct financial value
- UCV = usage and customer value
- PCV = product capability value
- DV = distribution value
- SOV = strategic option value
- LV = learning value
- IC = implementation cost
- EOC = exclusivity and opportunity cost
- ERC = expected risk cost
- CLC = concentration and lock-in cost

### Confidence-adjusted value

```text
CAV = GPV × CF
```

### Expected risk cost

```text
ERC = Σ(probability of risk i × financial impact of risk i)
```

### ROI

```text
ROI = (CAV - cash consideration - implementation cost) / (cash consideration + implementation cost)
```

### Comparability score

Default weighted score:

```text
Archetype similarity                 25%
Rights and exclusivity similarity    20%
Economic structure similarity        20%
Term and renewal similarity          10%
Distribution/usage similarity        10%
Integration burden similarity        10%
Source quality                        5%
```

## 3. Confidence model

Start with five dimensions, each scored 0–1:

- evidence quality;
- assumption stability;
- comparable quality;
- implementation certainty;
- partner execution confidence.

```text
CF = weighted average of the five dimensions
```

Default equal weights for MVP. Display the score and components separately.

## 4. Source policy

Every non-synthetic factual input must have an evidence record.

Every synthetic input must be visibly labeled **Synthetic**.

No public comparable should be presented as fully comparable without a normalization note.

# 05. Synthetic demo case

## Case label

**Atlas Knowledge Systems**

**Status:** Synthetic demonstration only

## Partner profile

Atlas is a fictional specialist-information provider with:

- a high-quality proprietary corpus;
- an API used by professional-services firms;
- a niche enterprise customer base;
- strong editorial processes;
- limited global distribution;
- no existing frontier-model partnership.

## Proposed partnership

Atlas proposes a three-year hybrid partnership including:

- annual data-license payment;
- API access;
- product integration;
- joint enterprise distribution;
- limited category exclusivity;
- minimum annual usage commitment;
- joint implementation team;
- renewal option after year three.

## Proposed terms

| Term | Synthetic value |
|---|---:|
| Contract term | 36 months |
| Upfront payment | $4.0M |
| Annual license | $6.0M |
| Minimum usage commitment | $3.0M per year |
| Implementation support | $1.5M equivalent |
| Exclusivity | Limited category exclusivity |
| Renewal | Two-year option |
| Termination | For cause; convenience after year two with fee |

## Initial valuation assumptions

### Downside

- Adoption reaches 45% of plan.
- Integration takes 12 months.
- Renewal probability is 35%.
- Limited distribution value.
- Higher-than-expected legal and implementation cost.

### Base

- Adoption reaches 75% of plan.
- Integration takes 7 months.
- Renewal probability is 60%.
- Moderate enterprise distribution value.
- Expected implementation cost.

### Upside

- Adoption reaches 110% of plan.
- Integration takes 4 months.
- Renewal probability is 80%.
- Strong enterprise distribution value.
- Additional product capability and strategic-option value.

## Scenario outputs

| Metric | Downside | Base | Upside |
|---|---:|---:|---:|
| Gross partnership value | $14.0M | $35.0M | $62.0M |
| Confidence factor | 0.55 | 0.72 | 0.78 |
| Confidence-adjusted value | $7.7M | $25.2M | $48.4M |
| Total proposed economic cost | $31.0M | $31.0M | $31.0M |
| Value gap | -$23.3M | -$5.8M | +$17.4M |

## Initial recommendation

**Decision:** Restructure or pilot.

### Rationale

- Base-case confidence-adjusted value is below the proposed economic cost.
- The upside case is attractive but depends on adoption and distribution assumptions that are not yet evidenced.
- Limited exclusivity creates material option cost.
- A staged pilot would create information value before a three-year commitment.

### Negotiation position

- Replace full three-year commitment with a 9–12 month pilot.
- Reduce upfront payment.
- Make part of the license fee usage-based.
- Limit exclusivity to defined segments and milestones.
- Add termination rights tied to implementation and quality thresholds.
- Preserve a renewal option if usage and product metrics are achieved.

### Walk-away condition

Decline if Atlas requires:

- broad category exclusivity;
- fixed three-year minimums without performance milestones;
- full upfront economics;
- weak termination rights;
- restrictions that materially limit alternative partnerships.

## Diligence questions

1. What share of the corpus is unique versus replaceable?
2. What percentage of the content can be licensed for model and product use?
3. What evidence supports expected enterprise distribution?
4. What implementation resources are contractually committed?
5. How will usage be measured and audited?
6. What quality, freshness, and rights warranties are provided?
7. What happens if regulatory or policy requirements change?
8. Which rights survive termination?
9. How does exclusivity narrow other strategic options?
10. What milestone structure would support a pilot?

## Starter comparable records

Use five fictional comparables:

1. **Northstar Data License** — recurring specialist corpus, no distribution.
2. **Meridian API Integration** — product integration, usage-based economics.
3. **Harbor Enterprise Channel** — distribution partnership with minimum commitments.
4. **Keystone Strategic Alliance** — co-development and joint GTM.
5. **Pioneer Hybrid Agreement** — license, API, integration, and limited exclusivity.

All records must be labeled synthetic.

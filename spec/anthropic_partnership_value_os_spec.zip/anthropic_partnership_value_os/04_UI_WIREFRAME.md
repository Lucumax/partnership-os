# 04. UI wireframe

## Global layout

- Left navigation: Dashboard, Opportunities, Comparables, Decision Briefs, Audit.
- Top bar: active case, stage, owner, last updated, `Export` button.
- Main canvas: 12-column grid.
- Right rail on analytical screens: assumptions, evidence, unresolved questions.

## 1. Dashboard

### Header

**Partnership portfolio**

Subhead: `Confidence-adjusted view of pipeline value, commitments, and decisions.`

### KPI row

- Pipeline value
- Confidence-adjusted value
- Proposed spend
- Active negotiations
- Decisions due in 30 days
- High-risk opportunities

### Main panels

- Stage funnel
- Value versus spend scatter plot
- Upcoming decisions table
- Concentration by archetype
- Recent assumption changes

## 2. Opportunity detail

### Header

- `Atlas Knowledge Systems`
- Badge: `Synthetic`
- Stage: `Valuation`
- Archetype: `Hybrid`

### Tabs

- Overview
- Proposal
- Valuation
- Comparables
- Negotiation
- Decision history

### Overview layout

Left 8 columns:

- opportunity summary;
- proposed economics;
- current recommendation;
- value range chart;
- top sensitivities.

Right 4 columns:

- confidence score;
- open questions;
- high risks;
- approval status.

## 3. Proposal intake

Two-column form.

Left:

- economic terms;
- rights;
- term and renewal;
- exclusivity;
- usage/distribution obligations.

Right:

- implementation obligations;
- legal/policy flags;
- evidence source;
- missing information.

Bottom action bar:

- Save draft
- Generate diligence questions
- Mark intake complete

## 4. Valuation workbench

### Top section

Three scenario cards: downside, base, upside.

Each card shows:

- gross value;
- confidence-adjusted value;
- ROI;
- payback;
- gap versus proposed price.

### Middle section

Waterfall chart for base-case value components.

### Lower section

Editable assumption table with:

- variable;
- downside/base/upside;
- evidence;
- confidence;
- owner;
- last updated.

### Right rail

- top five sensitivities;
- red-team flags;
- confidence-factor components.

## 5. Comparable library

Dense table with filters.

Top filters:

- archetype;
- term;
- exclusivity;
- source quality;
- synthetic/public;
- comparability score.

Expandable row shows:

- normalization factors;
- source notes;
- rationale for inclusion;
- value adjustments.

## 6. Negotiation brief

### Left panel

- opening position;
- target;
- reservation value;
- walk-away point;
- preferred structure.

### Center panel

Give/get matrix with columns:

- We give
- We get
- Economic impact
- Strategic impact
- Risk effect

### Right panel

- red lines;
- missing evidence;
- partner questions;
- conditions that change recommendation.

Bottom:

- Generate brief
- Approve brief
- Export Markdown

## 7. Decision history

Timeline with events:

- proposal imported;
- assumptions changed;
- comparable added/removed;
- AI challenge generated;
- recommendation revised;
- approval granted;
- decision recorded.

Each event displays actor, timestamp, rationale, and evidence links.

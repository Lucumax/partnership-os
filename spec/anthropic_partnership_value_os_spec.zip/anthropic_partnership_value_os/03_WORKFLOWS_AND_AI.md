# 03. Workflows and AI controls

## 1. End-to-end workflow

```text
Inbound proposal
→ structured intake
→ completeness and conflict check
→ diligence questions
→ comparable selection
→ assumption register
→ scenario valuation
→ sensitivity and red-team challenge
→ negotiation brief
→ cross-functional review
→ human approval
→ contracting / pilot / decline
→ realized-value tracking
→ benchmark-library update
```

## 2. AI-assisted actions

Claude may assist with:

- extracting terms from synthetic proposal text;
- identifying missing information;
- drafting diligence questions;
- classifying partnership archetype;
- summarizing comparable evidence;
- suggesting normalization factors;
- challenging assumptions;
- drafting a negotiation brief;
- explaining how a recommendation changes when assumptions change;
- producing a concise executive memo.

Claude may not:

- approve a partnership;
- invent missing commercial terms;
- silently alter assumptions;
- present a synthetic or inferred fact as sourced;
- choose a final negotiation position without human review;
- send communications externally;
- modify historical audit events.

## 3. Human approval gates

### Gate 1: Intake completeness

Human confirms the proposal fields and source labels.

### Gate 2: Assumption lock

Human approves the base-case assumptions used in the model.

### Gate 3: Comparable set

Human approves selected comparables and normalization adjustments.

### Gate 4: Recommendation

Human approves the opening position, target, reservation value, and walk-away point.

### Gate 5: Decision

Human records the final decision and rationale.

## 4. AI output labeling

Every AI-generated block must show:

- `AI draft` badge;
- generation timestamp;
- model identifier if available;
- source records used;
- unresolved uncertainty;
- human approval status.

## 5. Explainability requirements

For every recommendation, the app must answer:

1. Which assumptions drive the result?
2. Which comparable transactions were used?
3. How were they adjusted?
4. What is the confidence factor and why?
5. Which risk costs were included?
6. What evidence would change the recommendation?
7. Who approved the final view?

## 6. Deterministic fallback

When live AI is disabled, all demo flows must work using:

- fixture proposal text;
- deterministic extraction mappings;
- fixture comparables;
- rule-based diligence questions;
- precomputed scenario values;
- template-generated negotiation brief.

## 7. Red-team prompt behavior

The AI challenge pass should search for:

- double counting of value;
- unsupported comparables;
- hidden implementation costs;
- overly optimistic adoption;
- weak renewal assumptions;
- exclusivity costs omitted from valuation;
- concentration risk;
- false precision;
- conflation of partner claims with verified evidence;
- recommendations that exceed the model's confidence.

## 8. Privacy and security posture

For the MVP:

- use only synthetic data;
- no real contract ingestion;
- no browser persistence of secrets;
- no live AI call without explicit feature flag;
- no client-side exposure of private keys;
- no analytics requiring personal data;
- export only the current synthetic case.

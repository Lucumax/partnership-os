# Partnership Value OS

A proof-of-work package for Anthropic's Strategy & Operations, Product Partnerships role.

This package specifies a compact decision-support application and a companion executive deck. The app is the primary credibility artifact; the deck is the narrative layer used for sharing and interviews.

## Recommended build order

1. Build the static/local-first app from `01_PRODUCT_SPEC.md`.
2. Seed it with the synthetic case in `05_SYNTHETIC_DEMO_DATA.md`.
3. Validate against `06_ACCEPTANCE_CRITERIA.md`.
4. Use `07_GAMMA_FIRST_LOOK_PROMPT.md` to generate a first visual deck concept.
5. Rebuild the final presentation in PowerPoint using screenshots and outputs from the app.

## Contents

- `01_PRODUCT_SPEC.md` — product objective, scope, users, features, screens, and technical architecture
- `02_DATA_MODEL.md` — core entities, schemas, formulas, and evidence model
- `03_WORKFLOWS_AND_AI.md` — human/AI workflow, guardrails, approval gates, and traceability
- `04_UI_WIREFRAME.md` — page-by-page layout and interaction notes
- `05_SYNTHETIC_DEMO_DATA.md` — fictional partnership case and starter values
- `06_ACCEPTANCE_CRITERIA.md` — release gates and demo script
- `07_GAMMA_FIRST_LOOK_PROMPT.md` — prompt for a 9-slide Gamma concept deck
- `08_BUILD_PROMPT_V4_FLASH.md` — implementation prompt for a coding agent

## Product name

**Partnership Value OS**

Tagline: **Defensible partnership decisions when comparables are sparse.**

## Positioning

The artifact should feel like an internal strategy, finance, and partnerships operating tool, not a public SaaS product. It should demonstrate:

- valuation under uncertainty;
- comparable-transaction normalization;
- negotiation support;
- portfolio and lifecycle operations;
- Claude-assisted analysis with human approval;
- transparent assumptions and auditability.

## Non-goals

- No claim of using Anthropic's confidential data or internal deal information.
- No real counterparty names in the demo case.
- No production authentication, billing, or enterprise integrations in the first version.
- No autonomous negotiation recommendations without explicit human approval.
